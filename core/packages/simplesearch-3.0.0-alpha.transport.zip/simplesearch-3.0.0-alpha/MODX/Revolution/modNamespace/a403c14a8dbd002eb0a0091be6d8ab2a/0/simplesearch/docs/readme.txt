=====================
Snippet: SimpleSearch
=====================
Version: 3.0.0-alpha
Author: MODX LLC <help@modx.com>
License: GNU GPLv2 (or later at your option)

This is a simple search component. Please see the documentation at:
https://docs.modx.com/extras/revo/simplesearch

Bugs and feature requests
-------------------------
We value your feedback, feature requests and bug reports. Please issue them on GitHub (https://github.com/modxcms/SimpleSearch/issues/new).

Thanks for using SimpleSearch!
