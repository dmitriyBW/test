<?php
namespace SimpleSearch\Driver\MySQL;

use SimpleSearch\Driver\SimpleSearchDriverBasic;

class SimpleSearchDriverMySQL extends SimpleSearchDriverBasic {}
